package com.example.tsr_app.shared.session

import android.content.Intent
import android.util.Log
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.lifecycle.DefaultLifecycleObserver
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.firebase.FcmManagement
import com.example.tsr_app.shared.screen.TsrAppScreen

/**
 * Class that the app must implement and return using CarAppService.onCreateSession.
 * It serves as the entry point to display information on the car screen.
 * It has a lifecycle that informs the current state of the app on the car screen, such as when your app is visible or hidden.
 *
 * When a Session is started, such as when the app is first launched,
 * the host requests for the initial Screen to display using the onCreateScreen method.
 */
class TsrAppSession : Session(), DefaultLifecycleObserver {
    private lateinit var tsrAppScreen: TsrAppScreen
    private lateinit var fcmManagement: FcmManagement

    override fun onCreateScreen(intent: Intent): Screen {
        lifecycle.addObserver(this)
        // Sets the initial screen.
        Log.i(TAG, carContext.resources.getString(R.string.initializing_screen))
        tsrAppScreen = TsrAppScreen(carContext = carContext)
        // Initializes FcmManager, calling to initialize the single instance of the class.
        Log.i(TAG, carContext.resources.getString(R.string.initializing_firebase))
        FcmManagement.initialize(carContext = carContext, appScreen = tsrAppScreen)
        fcmManagement = FcmManagement.getInstance()
        fcmManagement.initialize()
        Log.i(TAG, carContext.resources.getString(R.string.get_device_token))
        fcmManagement.getToken()
        return tsrAppScreen
    }

    companion object {
        private const val TAG = "Tsr_Session"
        val instance = TsrAppSession()
    }
}