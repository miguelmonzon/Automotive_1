package com.example.tsr_app.shared.screen

import android.util.Log
import androidx.car.app.CarContext
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Pane
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.data.Sign
import com.example.tsr_app.shared.utils.Utils

/**
 * Contains the methods necessary to display the last detected traffic sign as the main image of the pane.
 */
class CurrentSign {

    private lateinit var currentSignCarIcon: CarIcon

    /**
     * Using a traffic sign name, obtain the matching Sign object.
     * This will provide the data of the currently detected traffic sign.
     */
    fun getData(carContext: CarContext, signName: String): Sign {
        // Get Signal data, searching by name.
        return Utils().getSignByName(context = carContext, name = signName)
    }

    /**
     * Using the imageRes property of the currently detected traffic sign,
     * create a CarIcon to place as the main image of the panel.
     */
    fun createImage(carContext: CarContext, currentSign: Sign) {
        try {
            // Create CarIcon for Traffic Sign image.
            currentSignCarIcon =
                Utils().sourceToCarIcon(context = carContext, resId = currentSign.imageRes)

        } catch (e: Exception) {
            Log.e(TAG, carContext.resources.getString(R.string.error_found), e)
        }
    }

    /**
     * Add the CarIcon of the currently detected traffic sign to the panel as its main image.
     */
    fun addImageToPane(paneBuilder: Pane.Builder, carContext: CarContext) {
        try {
            // Add currentSign CarIcon to the Pane.
            paneBuilder.setImage(currentSignCarIcon)
        } catch (e: Exception) {
            Log.e(TAG, carContext.resources.getString(R.string.error_found), e)
        }
    }

    companion object {
        private const val TAG = "Tsr_CurrentSign"
        val instance = CurrentSign()
    }
}