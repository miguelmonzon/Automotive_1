package com.example.tsr_app.shared.screen

import android.content.Context
import android.util.Log
import androidx.car.app.CarContext
import androidx.car.app.model.Pane
import androidx.car.app.model.Row
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.data.HistoryData.historySigns
import com.example.tsr_app.shared.data.Sign
import com.example.tsr_app.shared.utils.Utils

/**
 * Contains the methods necessary to display the list of traffic signs
 * in the HistoryData object as a list of rows on the pane.
 */
class History {
    private lateinit var rows: List<Row>
    private lateinit var receivedSignsList: MutableList<Sign>

    fun restructureContent(
        context: Context,
        currentSign: Sign,
        receivedSignsNameList: MutableList<String>
    ) {
        // Move the previous 'current signal' detected to the position 0 of the history.
        historySigns.add(index = 0, element = currentSign)

        receivedSignsList = mutableListOf()
        val validList = if (receivedSignsNameList.size <= 3) {
            receivedSignsNameList
        } else {
            receivedSignsNameList.slice(0..2)
        }

        validList.forEach {
            val sign = Utils().getSignByName(context = context, name = it.uppercase())
            receivedSignsList.add(sign)
        }

        var index = 0
        receivedSignsList.forEach {
            historySigns.add(index = index, element = it)
            index += 1
        }

        while (historySigns.size > 3) {
            historySigns.removeLast()
        }
    }

    /**
     * Create a list of rows containing the information necessary to display the traffic sign history.
     */
    fun createRows(carContext: CarContext, signList: List<Sign> = historySigns) {
        try {
            // Create Rows with the traffic Signs data provided by signList.
            val historyRows = mutableListOf<Row>()
            for (sign in signList) {
                val icon = Utils().sourceToCarIcon(carContext, sign.imageRes)
                val row =
                    Row.Builder().setTitle(carContext.resources.getString(sign.descriptionRes))
                        .setImage(icon)
                        .build()
                historyRows.add(row)
            }
            // Update History 'rows' property.
            rows = historyRows
        } catch (e: Exception) {
            Log.e(TAG, carContext.resources.getString(R.string.error_found), e)
        }
    }

    /**
     * Add history rows into the Pane Builder.
     */
    fun addRowsToPaneBuilder(paneBuilder: Pane.Builder, carContext: CarContext) {
        try {
            for (row in rows) {
                paneBuilder.addRow(row)
            }
        } catch (e: Exception) {
            Log.e(TAG, carContext.resources.getString(R.string.error_found), e)
        }
    }

    companion object {
        private const val TAG = "Tsr_History"
        val instance = History()
    }
}