package com.example.tsr_app.shared.data

import com.example.tsr_app.shared.R

/**
 * Contains the information of all Sign objects that can be displayed in
 * the Panel during the execution of the application.
 */
object SignsCatalog {
    val signs = listOf(
        Sign(
            nameRes = R.string.crosswalk,
            descriptionRes = R.string.crosswalk_description,
            imageRes = R.drawable.sign_crosswalk
        ),
        Sign(
            nameRes = R.string.sign_empty,
            descriptionRes = R.string.sign_empty_description,
            imageRes = R.drawable.sign_empty
        ),
        Sign(
            nameRes = R.string.sign_error,
            descriptionRes = R.string.sign_error_description,
            imageRes = R.drawable.sign_error
        ),
        Sign(
            nameRes = R.string.speed_limit_5,
            descriptionRes = R.string.speed_limit_5_description,
            imageRes = R.drawable.sign_speed_limit_5
        ),
        Sign(
            nameRes = R.string.speed_limit_10,
            descriptionRes = R.string.speed_limit_10_description,
            imageRes = R.drawable.sign_speed_limit_10
        ),
        Sign(
            nameRes = R.string.speed_limit_15,
            descriptionRes = R.string.speed_limit_15_description,
            imageRes = R.drawable.sign_speed_limit_15
        ),
        Sign(
            nameRes = R.string.speed_limit_20,
            descriptionRes = R.string.speed_limit_20_description,
            imageRes = R.drawable.sign_speed_limit_20
        ),
        Sign(
            nameRes = R.string.speed_limit_25,
            descriptionRes = R.string.speed_limit_25_description,
            imageRes = R.drawable.sign_speed_limit_25
        ),
        Sign(
            nameRes = R.string.speed_limit_30,
            descriptionRes = R.string.speed_limit_30_description,
            imageRes = R.drawable.sign_speed_limit_30
        ),
        Sign(
            nameRes = R.string.speed_limit_35,
            descriptionRes = R.string.speed_limit_35_description,
            imageRes = R.drawable.sign_speed_limit_35
        ),
        Sign(
            nameRes = R.string.speed_limit_40,
            descriptionRes = R.string.speed_limit_40_description,
            imageRes = R.drawable.sign_speed_limit_40
        ),
        Sign(
            nameRes = R.string.speed_limit_45,
            descriptionRes = R.string.speed_limit_45_description,
            imageRes = R.drawable.sign_speed_limit_45
        ),
        Sign(
            nameRes = R.string.speed_limit_50,
            descriptionRes = R.string.speed_limit_50_description,
            imageRes = R.drawable.sign_speed_limit_50
        ),
        Sign(
            nameRes = R.string.speed_limit_55,
            descriptionRes = R.string.speed_limit_55_description,
            imageRes = R.drawable.sign_speed_limit_55
        ),
        Sign(
            nameRes = R.string.speed_limit_60,
            descriptionRes = R.string.speed_limit_60_description,
            imageRes = R.drawable.sign_speed_limit_60
        ),
        Sign(
            nameRes = R.string.speed_limit_65,
            descriptionRes = R.string.speed_limit_65_description,
            imageRes = R.drawable.sign_speed_limit_65
        ),
        Sign(
            nameRes = R.string.speed_limit_70,
            descriptionRes = R.string.speed_limit_70_description,
            imageRes = R.drawable.sign_speed_limit_70
        ),
        Sign(
            nameRes = R.string.speed_limit_75,
            descriptionRes = R.string.speed_limit_75_description,
            imageRes = R.drawable.sign_speed_limit_75
        ),
        Sign(
            nameRes = R.string.speed_limit_80,
            descriptionRes = R.string.speed_limit_80_description,
            imageRes = R.drawable.sign_speed_limit_80
        ),
        Sign(
            nameRes = R.string.stop_red,
            descriptionRes = R.string.stop_red_description,
            imageRes = R.drawable.sign_stop
        ),
        Sign(
            nameRes = R.string.stop_yellow,
            descriptionRes = R.string.stop_yellow_description,
            imageRes = R.drawable.sign_stop_yellow
        ),
        Sign(
            nameRes = R.string.wildlife_crossing,
            descriptionRes = R.string.wildlife_crossing_description,
            imageRes = R.drawable.sign_wildlife_crossing
        ),
        Sign(
            nameRes = R.string.work_zone,
            descriptionRes = R.string.work_zone_description,
            imageRes = R.drawable.sign_work_zone
        ),
    )
}