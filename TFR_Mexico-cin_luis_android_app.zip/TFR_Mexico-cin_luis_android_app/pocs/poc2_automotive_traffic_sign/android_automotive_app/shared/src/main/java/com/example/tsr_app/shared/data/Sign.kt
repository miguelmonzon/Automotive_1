package com.example.tsr_app.shared.data

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/**
 * Constructs the Sign object with its properties, this object will be used to set the content of the pane.
 */
data class Sign(
    @StringRes val nameRes: Int,
    @StringRes val descriptionRes: Int,
    @DrawableRes val imageRes: Int
)
