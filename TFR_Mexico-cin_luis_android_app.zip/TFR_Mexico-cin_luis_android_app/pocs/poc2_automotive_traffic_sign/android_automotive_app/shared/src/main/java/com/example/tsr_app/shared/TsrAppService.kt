package com.example.tsr_app.shared

import android.annotation.SuppressLint
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import com.example.tsr_app.shared.session.TsrAppSession

/**
 * Is responsible for validating that a host connection can be trusted using createHostValidator and
 * subsequently providing Session instances for each connection using onCreateSession.
 */
class TsrAppService : CarAppService() {

    @SuppressLint("PrivateResource")
    override fun createHostValidator(): HostValidator {
        return HostValidator.Builder(applicationContext)
            .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
            .build()
    }

    override fun onCreateSession(): Session {
        return TsrAppSession.instance
    }
}