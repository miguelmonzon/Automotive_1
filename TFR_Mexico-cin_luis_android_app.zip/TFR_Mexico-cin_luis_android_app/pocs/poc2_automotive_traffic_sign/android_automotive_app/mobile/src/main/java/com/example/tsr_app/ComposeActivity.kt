package com.example.tsr_app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.tsr_app.screen.TsrScreen
import com.example.tsr_app.ui.theme.AppTheme

class ComposeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                val tsrScreen = TsrScreen()
                tsrScreen.TSRApp()
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TsrPreview() {
    AppTheme {
        val tsrScreen = TsrScreen()
        tsrScreen.TSRApp()
    }
}