# Machine Learning PoC Corps

Welcome to the Machine Learning PoC Corps Repository! This repository serves as a hub for various Machine Learning Proof of Concepts (PoCs) and documentation related to our Machine Learning Academy Bootcamp.

## Table of Contents

1. [Introduction](#introduction)
2. [Machine Learning PoCs](#machine-learning-pocs)
    - [PoC 1: Medical Skin Condition Detection](./pocs/poc1_medical_skin)
    - [PoC 2: Automotive Traffic Sign Recognition](./pocs/poc2_automotive_traffic_sign)
3. [Machine Learning Academy Bootcamp](#machine-learning-academy-bootcamp)
    - [Overview](./bootcamp/overview.md)
    - [Curriculum](./bootcamp/curriculum.md)
    - [Resources](./bootcamp/resources.md)
4. [Getting Started](#getting-started)
    - [Setting up the Environment](./getting-started/setup.md)
    - [Requirements](./getting-started/requirements.md)
5. [Contributing](#contributing)
6. [License](#license)

## Introduction

This repository is a collection of Machine Learning Proof of Concepts (PoCs) and documentation for our Machine Learning Academy Bootcamp. Whether you are working on any of both initiatives, this repository is designed to provide a comprehensive resource for those ends.

## Machine Learning PoCs

Explore our Machine Learning PoCs to understand and experiment with various machine learning algorithms and applications.

- [PoC 1: Medical Skin Condition Detection](./pocs/poc1_medical_skin): Android application that interfaces with the TI TDA4VM SBC to perform inference analysis on skin images to detect eczema presence.
- [PoC 2: Medical Skin Condition Detection](./pocs/poc2_automotive_traffic_sign): Android Auto[motive] application that interfaces with the TI TDA4VM SBC to perform real-time detection of traffic signs on the road even if they are damaged.

Each PoC comes with its own documentation and codebase to help you understand the implementation details.

## Machine Learning Academy Bootcamp

Our Machine Learning Academy Bootcamp is a comprehensive learning program covering a wide range of machine learning topics.

- [Overview](./bootcamp/overview.md): A high-level introduction to the bootcamp.
- [Curriculum](./bootcamp/curriculum.md): Detailed breakdown of the topics covered.
- [Resources](./bootcamp/resources.md): Additional resources for deeper understanding.

## Getting Started

If you're new to this repository, here's how you can get started:

- [Setting up the Environment](./getting-started/setup.md): Instructions on setting up your local environment.
- [Requirements](./getting-started/requirements.md): Prerequisites for running the code and exercises.

## Contributing

We welcome contributions! If you have a new PoC to add or want to improve existing documentation, please refer to our [contribution guidelines](./CONTRIBUTING.md).

