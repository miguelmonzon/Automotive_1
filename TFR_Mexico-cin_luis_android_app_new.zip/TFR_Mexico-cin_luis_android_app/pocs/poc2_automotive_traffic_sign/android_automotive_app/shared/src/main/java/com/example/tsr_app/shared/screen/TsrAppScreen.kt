package com.example.tsr_app.shared.screen

import android.annotation.SuppressLint
import android.util.Log
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.data.HistoryData.historySigns
import com.example.tsr_app.shared.data.Sign

/**
 * Builds the panel that will be displayed on the device screen while the application is running.
 */
class TsrAppScreen(carContext: CarContext) : Screen(carContext) {
    var currentSignName: String = this.carContext.resources.getString(R.string.sign_empty)
    var prevMainSignal = Sign(
        nameRes = R.string.sign_empty,
        descriptionRes = R.string.sign_empty_description,
        imageRes = R.drawable.sign_empty
    )
    private val history = History.instance
    private val mainSign = CurrentSign.instance
    private lateinit var pane: Pane

    @SuppressLint("RestrictedApi")
    override fun onGetTemplate(): Template {
        val paneBuilder = Pane.Builder().setLoading(false)
        lateinit var currentTrafficSign: Sign

        try {
            // Using the name of the traffic sign, create its CarIcon and add it to the pane as its main image.
            currentTrafficSign = mainSign.getData(
                carContext = this.carContext, signName = currentSignName
            )
            mainSign.createImage(
                carContext = this.carContext,
                currentSign = currentTrafficSign
            )
            mainSign.addImageToPane(paneBuilder = paneBuilder, carContext = this.carContext)

            // Comments to be logged when testing the pane update.
            Log.i(
                TAG,
                this.carContext.resources.getString(R.string.adding_rows) +
                        "${this.carContext.resources.getString(R.string.current_sign__equal_to)} $currentSignName\n" +
                        "${this.carContext.resources.getString(R.string.history_0_equal_to)}${
                            this.carContext.resources.getString(
                                historySigns[0].nameRes
                            )
                        } \n" +
                        "${this.carContext.resources.getString(R.string.history_1_equal_to)}${
                            this.carContext.resources.getString(
                                historySigns[1].nameRes
                            )
                        } \n" +
                        "${this.carContext.resources.getString(R.string.history_2_equal_to)}${
                            this.carContext.resources.getString(
                                historySigns[2].nameRes
                            )
                        }"
            )

            // Create rows with history list information and add them to the Pane Builder.
            history.createRows(carContext = this.carContext)
            history.addRowsToPaneBuilder(paneBuilder = paneBuilder, carContext = this.carContext)

            //Build Pane
            pane = paneBuilder.build()

        } catch (e: Exception) {
            // Initialize the errorPaneBuilder, used in case of error while building the Pane.
            val errorPaneBuilder = Pane.Builder().setLoading(false)

            // Create a row with the error legend to be displayed in the 'error Pane'.
            val row = Row.Builder()
                .setTitle(this.carContext.resources.getString(R.string.error_found_expression))
                .build()
            Log.e(TAG, this.carContext.resources.getString(R.string.error_found), e)
            // Create CarIcon to be displayed in the 'error Pane'.
            currentTrafficSign = mainSign.getData(
                carContext = this.carContext,
                signName = this.carContext.resources.getString(R.string.sign_error)
            )
            mainSign.createImage(
                carContext = this.carContext,
                currentSign = currentTrafficSign
            )
            mainSign.addImageToPane(paneBuilder = errorPaneBuilder, carContext = this.carContext)
            // Build 'error' Pane.
            pane = errorPaneBuilder.addRow(row).build()
        }
        // Save the value of the last detected Traffic Sign.
        prevMainSignal = currentTrafficSign
        //Return Created Pane Template (Error or not).
        return PaneTemplate.Builder(pane)
            .setTitle(this.carContext.resources.getString(R.string.tsr_app_title))
            .build()
    }

    companion object {
        private const val TAG = "Tsr_Screen"
    }
}