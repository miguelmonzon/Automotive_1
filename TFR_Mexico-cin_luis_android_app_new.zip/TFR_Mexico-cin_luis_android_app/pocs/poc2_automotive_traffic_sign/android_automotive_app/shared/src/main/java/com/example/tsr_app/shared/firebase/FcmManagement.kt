package com.example.tsr_app.shared.firebase

import android.content.Context
import android.util.Log
import androidx.car.app.CarContext
import androidx.core.content.ContextCompat.getString
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.data.SignsCatalog
import com.example.tsr_app.shared.screen.History
import com.example.tsr_app.shared.screen.TsrAppScreen
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.RemoteMessage

/**
 * Initialized the FirebaseMessaging instance, returns the device token,
 * and manages received notifications.
 */
class FcmManagement private constructor() {
    private lateinit var firebaseMessaging: FirebaseMessaging
    private lateinit var carContext: CarContext
    private lateinit var appScreen: TsrAppScreen
    private val history = History.instance

    /**
     * Initialize the firebaseMessaging instance.
     */
    fun initialize(): Boolean {
        try {
            firebaseMessaging = FirebaseMessaging.getInstance()

        } catch (e: Exception) {
            Log.e(TAG, getString(this.carContext, R.string.error_found), e)
            return false
        }
        return true
    }

    /**
     * Use the token property to generate a unique token for the device.
     * The token is returned as a Task object, so add a listener to the task to handle the result.
     * If the task is successful, retrieve the token from the result and log it.
     * This token can then be sent to the server for further processing.
     */
    fun getToken(): String {
        var token = ""
        firebaseMessaging.token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                token = task.result
                Log.d(TAG, "${getString(this.carContext, R.string.token)} $token")
                // Here the token can be sent to the server.
            } else {
                Log.w(TAG, getString(this.carContext, R.string.failed_token))
            }
        }
        return token
    }

    /**
     * Manages the content of the received notification to obtain the information
     * required to update both the main signal image and the history content.
     * Will be called when a new message is received from Firebase.
     */
    fun manageNotification(context: Context, notification: RemoteMessage.Notification?) {
        val title: String?
        val body: String?

        if (notification != null) {
            body = notification.body
            title = notification.title
            // This line will print out push message which will be sent from the server.
            Log.i(
                TAG, "${context.resources.getString(R.string.notification_title)}$title \n" +
                        "${context.resources.getString(R.string.notification_body)}$body"
            )
            if (title?.uppercase() == context.resources.getString(R.string.detections)) {
                if (body != null && body != "") {
                    // Convert the received body into a list of strings, each string shall be a sign name.
                    var signList = createSignList(message = body)
                    // Remove invalid signal names from the received list to avoid processing them.
                    signList = getValidList(namesList = signList)
                    // If none of the sign names are correct, do not refresh the Pane.
                    if (signList.isNotEmpty()) {
                        // Change the name of the currentSign so it'll be updated on the pane when invalidate it.
                        appScreen.currentSignName = signList[0].uppercase()
                        // Remove from the list the name of the currentSign.
                        signList.removeAt(index = 0).toList()
                        // Recreate the history list content.
                        history.restructureContent(
                            context = context,
                            currentSign = appScreen.prevMainSignal,
                            receivedSignsNameList = signList
                        )
                        // Overrides the current panel, triggering the screen refresh.
                        Log.i(TAG, context.resources.getString(R.string.invalidating_pane))
                        appScreen.invalidate()
                    }
                } else {
                    Log.i(TAG, context.resources.getString(R.string.invalid_sign_received))
                }
            }
        }
    }

    // Transform a string into a comma-separated list of sign names.
    private fun createSignList(message: String): MutableList<String> {
        val withOutSpaces = message.filterNot { it.isWhitespace() }
        return withOutSpaces.split(",").toMutableList()
    }

    // Returns true if the received string matches the string corresponding to any
    // Sign.nameRes in the SignsCatalog; otherwise it returns false.
    private fun validateName(signName: String): Boolean {
        val nameExist = SignsCatalog.signs.any {
            this.carContext.resources.getString(it.nameRes) == signName.uppercase()
        }
        return nameExist
    }

    // Returns a new list of sign names, with no invalid sign names existing.
    private fun getValidList(namesList: MutableList<String>): MutableList<String> {
        val validNamesList = mutableListOf<String>()
        namesList.forEach {
            val valid = validateName(it)
            if (valid) {
                validNamesList.add(it)
            }
        }
        Log.i(
            TAG,
            this.carContext.resources.getString(R.string.validated_names_list) + validNamesList.toString()
        )
        return validNamesList
    }

    companion object {
        private const val TAG = "Tsr_FcmManagement"

        @Volatile
        private var instance: FcmManagement? = null

        // Initializes the single instance of the FcmManagement class.
        fun initialize(carContext: CarContext, appScreen: TsrAppScreen) {
            instance ?: synchronized(this) {
                instance ?: FcmManagement().also {
                    it.carContext = carContext
                    it.appScreen = appScreen
                    instance = it
                }
            }
        }

        // Returns the single instance of the FcmManagement class if it has been previously initialized.
        fun getInstance(): FcmManagement {
            return instance
                ?: throw IllegalStateException("FcmManagement has not been initialized. Call initialize() first.")
        }
    }
}
