package com.example.tsr_app.shared.utils

import android.content.Context
import androidx.annotation.DrawableRes
import androidx.car.app.CarContext
import androidx.car.app.model.CarIcon
import androidx.core.graphics.drawable.IconCompat
import com.example.tsr_app.shared.R
import com.example.tsr_app.shared.data.Sign
import com.example.tsr_app.shared.data.SignsCatalog

/**
 * It contains methods for various uses in different application packages.
 */
class Utils {

    /**
     *  Create a CarIcon by providing a drawable resource Id.
     */
    fun sourceToCarIcon(context: CarContext, @DrawableRes resId: Int): CarIcon {
        val iconCompat = IconCompat.createWithResource(context, resId)
        return CarIcon.Builder(iconCompat).build()
    }

    /**
     * Returns a Sign object,  filtered from the SignsCatalog using the name of the sign.
     */
    fun getSignByName(context: CarContext, name: String): Sign {
        val matchingSign = SignsCatalog.signs.filter {
            context.resources.getString(it.nameRes) == name
        }
        // If no matches found, return the 'Error Sign' object. Otherwise, return the match found.
        return if (matchingSign.isEmpty()) {
            Sign(
                nameRes = R.string.sign_error,
                descriptionRes = R.string.sign_error_description,
                imageRes = R.drawable.sign_error
            )
        } else {
            matchingSign[0]
        }
    }

    /**
     * Returns a Sign object,  filtered from the SignsCatalog using the name of the sign.
     */
    fun getSignByName(context: Context, name: String): Sign {
        val matchingSign = SignsCatalog.signs.filter {
            context.resources.getString(it.nameRes) == name
        }
        // If no matches found, return the 'Error Sign' object. Otherwise, return the match found.
        return if (matchingSign.isEmpty()) {
            Sign(
                nameRes = R.string.sign_error,
                descriptionRes = R.string.sign_error_description,
                imageRes = R.drawable.sign_error
            )
        } else {
            matchingSign[0]
        }
    }
}