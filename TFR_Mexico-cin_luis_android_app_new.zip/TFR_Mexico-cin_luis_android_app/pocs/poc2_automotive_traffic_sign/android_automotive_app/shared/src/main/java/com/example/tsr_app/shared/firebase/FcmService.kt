package com.example.tsr_app.shared.firebase

import android.util.Log
import com.example.tsr_app.shared.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Extends FirebaseMessagingService to take action in response to FirebaseMessagingService events,
 * including the "onMessageReceived" event.
 */
class FcmService() : FirebaseMessagingService() {
    private lateinit var fcmManagement: FcmManagement
    override fun onCreate() {
        super.onCreate()
        try {
            fcmManagement = FcmManagement.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, resources.getString(R.string.error_found), e)
        }

    }

    /**
     * By overriding the method FirebaseMessagingService.onMessageReceived,
     * actions can be performed based on the received RemoteMessage object and get the message data.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val notification = remoteMessage.notification
        // Handle incoming messages here.
        try {
            if (fcmManagement == null) {
                fcmManagement = FcmManagement.getInstance()
            }
            fcmManagement.manageNotification(
                context = this.applicationContext,
                notification = notification
            )
        } catch (e: Exception) {
            Log.e(TAG, resources.getString(R.string.error_found), e)
        }
    }

    /**
     * Called if the FCM registration token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the
     * FCM registration token is initially generated so this is where you would retrieve the token.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i(TAG, "${resources.getString(R.string.refreshed_token)}$token")
    }

    override fun onDeletedMessages() {
        super.onDeletedMessages()
        Log.d(TAG, resources.getString(R.string.device_not_registered))
    }

    override fun onSendError(messageId: String, exception: Exception) {
        super.onSendError(messageId, exception)
        Log.d(TAG, "${resources.getString(R.string.error_found)}$exception")
    }


    companion object {
        private const val TAG = "Tsr_FcmService"
    }
}