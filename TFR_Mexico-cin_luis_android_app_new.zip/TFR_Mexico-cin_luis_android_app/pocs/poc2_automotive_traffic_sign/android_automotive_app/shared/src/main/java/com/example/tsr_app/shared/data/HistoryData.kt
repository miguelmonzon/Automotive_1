package com.example.tsr_app.shared.data

import com.example.tsr_app.shared.R

/**
 * Contains the structure of the list of Signs that will be displayed in the history section on the screen.
 */
object HistoryData {
    var historySigns = mutableListOf(
        Sign(
            nameRes = R.string.sign_empty,
            descriptionRes = R.string.sign_empty_description,
            imageRes = R.drawable.sign_empty
        ),
        Sign(
            nameRes = R.string.sign_empty,
            descriptionRes = R.string.sign_empty_description,
            imageRes = R.drawable.sign_empty
        ),
        Sign(
            nameRes = R.string.sign_empty,
            descriptionRes = R.string.sign_empty_description,
            imageRes = R.drawable.sign_empty
        ),
    )
}