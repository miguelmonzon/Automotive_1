# Application Overview

In general terms, the project is made up of ***four main elements***: An **embedded detection system** (TDA4VM), which will acquire the image and process it to detect traffic signs of interest; the information obtained by the detection system will be sent to a **Python API** that will translate the data so that the Andorid application can use it. To make this information available to the Android app,  **Firebase Cloud Messaging** (FCM) is used. The Python API will publish the data to FCM; once new data is available in FCM, it will notify the **Android app**, which is the one documented here, so it can update its UI to make the data available to the user.
```mermaid
---
title: Entity relationship
---
erDiagram
    Detection_system_TDA4VM ||--|| Python_API : communicates
    Python_API ||--|| Firebase_cloud_messaging : publish
    Firebase_cloud_messaging ||--|| TSR_Android_App : notify
```

## UI Design
Broadly speaking, the UI has three components: **Title**, will display a descriptive name of the application; **main image**, it will show the last detected traffic sign; **history**, a group of three rows that will show the image and description of the last three traffic signs detected before the one shown as the main image.
<img width="463" alt="9" src="https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/54847f85-0e36-4fef-959d-c72e895a03ed">

When starting the application, before any traffic signs are detected, both the main image and the history rows will show empty images (dark squares).
<img width="414" alt="image" src="https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/42304e42-93d6-4d1f-8073-23eb6c69f6d1">

As the detection system starts with the detection, it will send the information to the Python API, it will publish the data to Firebase and finally the latter will notify the Android App, this is when the UI starts its update; first the main Image will show the last detected image and with the next detected signals the main image will go to the first row of the history and a new main image will be shown. The history will be updated from top to bottom as more traffic signs are detected.
<img width="374" alt="image" src="https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/e8a18a52-62ad-4582-82fa-d350bf2af395">

# Basics
## OS
The _TSR_app_ is based on the **Android Automotive OS**, which is an Android-based infotainment system built into vehicles. 
> The car's system is a standalone Android-powered device that is optimized for driving. With Android Automotive OS, users install your app directly onto the car instead of their phones.
[Android Automotive OS](https://developer.android.com/training/cars#automotive-os)

## Library
The **Android for Cars App Library** was used to develop the application.
> The Android for Cars App Library lets you bring your navigation, point of interest (POI), and internet of things (IOT) apps to the car. It does so by providing a set of templates designed to meet driver distraction standards and taking care of details like the variety of car screen factors and input modalities.
[Android for Cars App Library](https://developer.android.com/training/cars/apps#create-carappservice)

Apps built using the Car App Library don't run directly on Android Auto or Android Automotive OS. Instead, they rely on a host app that communicates with client apps and renders the client's user interfaces on their behalf. Android Auto itself is a host and the Google Automotive App Host is the host used on Android Automotive OS vehicles with Google built-in. The following are the key classes of the Car App Library that must be extend when building the app [Learn Car App Library Fundamentals](https://developer.android.com/codelabs/car-app-library-fundamentals?hl=en#2):

### CarAppService
CarAppService is a subclass of Android's Service class and serves as the entry point for host applications to communicate with client apps. Its main purpose is to create Session instances that the host app interacts with.

### Session
A Session can be thinked as an instance of a client app running on a display in the vehicle. It has a life cycle of its own that can be used to initialize and tear down resources used throughout the Session instance's existence. There is a one-to-many relationship between CarAppService and Session.

### Screen
Screen instances are responsible for generating the user interfaces rendered by host apps. These user interfaces are represented by Template classes that each model a specific type of layout. Each Session manages a stack of Screen instances that handle user flows through the different parts of the app. As with a Session, a Screen has a lifecycle of its own.

![How it woks!](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/9015b267-1725-4e06-a8e7-8feef67f1a18)

### Template
From the templates provided by the Android Automotive App Library, the one selected to create the app's UI was the **Pane Template** which includes:
- Header with optional action strip
- Up to 2 buttons, where one can be designated as primary (optional; apps can use action strip buttons instead)
- Up to 4 non-actionable rows (1 row is mandatory)
- Optional large image (see example).

From the elements that can be used when working with a Pane Template, only the **following were used for the application**:
- Header, to show the name of the application.
- 3 non-actionable rows to display the last 3 traffic sign images, with description, detected before the current traffic sign (History).
- Large image to display the current/last detected traffic sign image.

For more details about this template, see [Pane Template](https://developers.google.com/cars/design/create-apps/apps-for-drivers/templates/pane-template#requirements).

## API integration
The application is expected to update the user interface with the data received from the traffic sign detection system for which a Python API will act as an intermediary to perform communication between the detection hardware and the Android application.  

One mechanism for the Python API to notify the Android app about new data without the need for continuous polling is to use push notifications.

>**What are push notifications?**
> Push notifications are messages that are sent from a server to an app on a user's device. They can be used to deliver important updates, reminders, or promotions directly to the user's device, even when the app is not actively running.
> **Why use push notifications in Android?**
> There are several benefits to using push notifications in Android apps. Firstly, they allow you to deliver important information and updates to your users in real-time.
> [Android Push Notifications with Kotlin: A Step-by-Step Guide](https://dopebase.com/android-push-notifications-kotlin-step-step-guide)

### Firebase
>Firebase is a serverless or backend as a service (BaaS) solution from Google. 
[An Android Developer's Guide to Using Firebase With Kotlin](https://www.waldo.com/blog/using-firebase-with-kotlin)

With Firebase, the following functionalities can be added to the app, among others, without managing a server: User authentication, database, file storage, notifications.

#### Prerequisites:
- Android Studio (Version 4.0+)
- An emulator or physical Android device
- A Google account (Gmail)

#### Setup
1. Create a new project: Open your [Firebase Console](https://console.firebase.google.com/),  click "Add Project" and follow the instructions to create the project.
![1](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/ec729f74-0c86-41ec-8787-313ab5dd20c2)
2. Add Android app to Firebase: 
    - Click the Android icon.
      ![1_2](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/29743c29-1b5a-4b9a-a25f-eb0803d2f661)
    - Add the Android Package Name and the App nickname.
    - Obtain the application's SHA-1 signing certificate by running the  *signingReport* Gradle task in the Android project.

      ![3](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/b88f124f-e2a4-4e3a-a224-ba438907f4df)
      ![4](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/e1480998-80d7-4d2e-876e-a837ebef5db6)
    - Add the obtained SHA-1 signing certificate to the application registration in Firebase and click "Register app".

      ![5](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/5517fecc-de59-4ef9-9c2d-dd199e6e7785)
    - Follow steps 2 to 4 and click "Go to Console".
      ![6](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/3fb5a62d-a4ce-4ec4-bec8-1037de034e7c)
      ![7](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/488e8657-2c01-420d-bc7a-b36aad1f3231)
      ![8](https://github.com/Deloitte-US-Consulting/TFR_Mexico/assets/150169512/bdf71c80-bcee-4ecd-9052-ae2844951aac)

Now the Firebase service is ready to work with the Android Studio app.

# Code Structure
```
└───android_automotive_app
    ├───automotive
    │   └───src
    │       ├───androidTest
    │       │   └───java
    │       │       └───com
    │       │           └───example
    │       │               └───tsr_app
    │       ├───main
    │       │   └───res
    │       │       ├───drawable
    │       │       ├───mipmap-anydpi
    │       │       ├───mipmap-hdpi
    │       │       ├───mipmap-mdpi
    │       │       ├───mipmap-xhdpi
    │       │       ├───mipmap-xxhdpi
    │       │       ├───mipmap-xxxhdpi
    │       │       └───values
    │       └───test
    │           └───java
    │               └───com
    │                   └───example
    │                       └───tsr_app
    ├───gradle
    │   └───wrapper
    ├───mobile
    │   └───src
    │       ├───androidTest
    │       │   └───java
    │       │       └───com
    │       │           └───example
    │       │               └───tsr_app
    │       ├───main
    │       │   ├───java
    │       │   │   └───com
    │       │   │       └───example
    │       │   │           └───tsr_app
    │       │   │               ├───screen
    │       │   │               └───ui
    │       │   │                   └───theme
    │       │   └───res
    │       │       ├───drawable
    │       │       ├───font
    │       │       ├───mipmap-anydpi
    │       │       ├───mipmap-anydpi-v26
    │       │       ├───mipmap-hdpi
    │       │       ├───mipmap-mdpi
    │       │       ├───mipmap-xhdpi
    │       │       ├───mipmap-xxhdpi
    │       │       ├───mipmap-xxxhdpi
    │       │       ├───values
    │       │       ├───values-night
    │       │       └───xml
    │       └───test
    │           └───java
    │               └───com
    │                   └───example
    │                       └───tsr_app
    └───shared
        └───src
            └───main
                ├───java
                │   └───com
                │       └───example
                │           └───tsr_app
                │               └───shared
                │                   ├───data
                │                   ├───firebase
                │                   ├───screen
                │                   ├───session
                │                   └───utils
                └───res
                    ├───drawable
                    ├───font
                    ├───mipmap-anydpi
                    ├───mipmap-anydpi-v26
                    ├───mipmap-hdpi
                    ├───mipmap-mdpi
                    ├───mipmap-xhdpi
                    ├───mipmap-xxhdpi
                    ├───mipmap-xxxhdpi
                    ├───values
                    └───xml
```
While the code structure includes three main modules (automotive, mobile and shared), the core of the application's functionality is allocated in the _*shared*_ module. The automotive module will be used to run the application on the automotive device, while the mobile module is in _TODO_ state in case of future applications.

## Shared module
### AndroidManifest.xml
Contains all of the elements that should be shared across the application, that includes the declaration of services used, such as CarAppService and FcmService.
```html
        <service
            android:name=".TsrAppService"
            android:exported="true">
            <intent-filter>
                <action android:name="androidx.car.app.CarAppService" />
                <category android:name="androidx.car.app.category.POI" />
            </intent-filter>
        </service>

        <service
            android:name=".firebase.FcmService"
            android:exported="false">
            <intent-filter>
                <action android:name="com.google.firebase.MESSAGING_EVENT" />
            </intent-filter>
        </service>
```
### src.main.java.com.example.tsr_app.shared
#### data
The objects and classes required to define the type of data to be displayed in the user interface are declared in this package.
```mermaid
---
title: data
---
classDiagram
note for HistoryData "Contains the structure of the list of Signs that will be displayed \nin the history section on the screen."
    class HistoryData{
        +historySigns: MutableListOf~Sign~
    }
note for Sign "Constructs the Sign object with its properties, \nthis object will be used to set the content of the pane."
    class Sign{
        +nameRes: Int
        +descriptionRes: Int
        +imageRes: Int
    }
note for SignsCatalog "Contains the information of all Sign objects that can be displayed \nin the Panel during the execution of the application."
    class SignsCatalog{
        +signs: ListOf~Sign~ 
    }
```
#### firebase
Its classes manage all actions related to communication with Firebase, including receiving the Strings that indicate the detected traffic signs.
```mermaid
---
title: firebase
---
classDiagram
note for FcmManagement "Initialized the FirebaseMessaging instance, returns the device token, \nand manages received notifications."
    class FcmManagement{
        - firebaseMessaging: FirebaseMessaging
        - carContext: CarContext
        - appScreen: TsrAppScreen
        - history: History
        -Instance: FcmManagement 
        -TAG: String 
        +Initialize() Boolean
        +getToken() String
        +manageNotification(context: Context, notification: RemoteMessage.Notification?)
        +createSignList(message: String) MutableList~String~
        +initialize(carContext: CarContext,appScreen: TsrAppScreen)
        +getInstance() FcmManagement
    }
note for  FcmService " Extends FirebaseMessagingService to take action in response to \nFirebaseMessagingService events, including the onMessageReceived event."
    class FcmService{
        -fcmManagement: FcmManagement
        -TAG: String 
        +onCreate()
        +onMessageReceived(remoteMessage: RemoteMessage)
        +onNewToken(token: String) 
        +onDeletedMessages()
        +onSendError(messageId: String, exception: Exception)
    }
```
#### screen
Contains the classes with the elements and logic necessary to manage the content of the user interface.
```mermaid
---
title: screen
---
classDiagram
note for CurrentSign "Contains the methods necessary to display \nthe last detected traffic sign as the main image of the pane."
    class CurrentSign{
        - currentSignCarIcon: CarIcon
        - TAG: String
        - Instance: CurrentSign
        +getData(carContext: CarContext, signName: String)Sign
        +createImage(carContext: CarContext, currentSign: Sign)
        +addImageToPane(paneBuilder: Pane.Builder, carContext: CarContext)  
    }
    note for History "Contains the methods necessary to display the list of traffic signs in \nthe HistoryData object as a list of rows on the pane."
    class History{
        -rows: List~Row~
        -receivedSignsList: MutableList~Sign~
        -TAG: String
        -Instance: History 
        +restructureContent(context: Context, currentSign: Sign, receivedSignsNameList: MutableList~String~)
        +createRows(carContext: CarContext, signList: List~Sign~ = historySigns)
        + addRowsToPaneBuilder(paneBuilder: Pane.Builder, carContext: CarContext) 
    }
    note for TsrAppScreen "Builds the panel that will be displayed on \nthe device screen while the application is running."
    class TsrAppScreen{
        +currentSignName: String
        -history: History
        -mainSign: CurrentSign
        -pane: Pane
        -TAG: String
        +onGetTemplate() Template
    }
```
#### session
It contains only one class, the one that serves as the entry point for displaying information on the car screen.
```mermaid
---
title: session
---
classDiagram
    class TsrAppSession {
        -tsrAppScreen: TsrAppScreen
        -fcmManagement: FcmManagement
        -TAG: String
        -instance: TsrAppSession
        +onCreateScreen(intent: Intent) Screen
    }
```
#### utils
With only one class contained, that class stores methods for various uses in different application packages.
```mermaid
---
title: utils
---
classDiagram
    class Utils {
        +sourceToCarIcon(context: CarContext, @DrawableRes resId: Int) CarIcon
        +getSignByName(context: CarContext, name: String) Sign
        +getSignByName(context: Context, name: String) Sign
    }
```
#### TsrAppService
Class responsible for validating that a host connection can be trusted using createHostValidator and subsequently providing Session instances for each connection using onCreateSession.
```mermaid
classDiagram
    class TsrAppService {
        + createHostValidator() HostValidator
        + onCreateSession() Session
    }
```

### src.main.res
#### drawable
All the xml files of the vector assets used in the UI are stored here.

#### font
ttf files corresponding to fonts that can be used in the UI, this is only used in the mobile module, specifically on *Type.kt*, whose logic is in *TODO* state.

#### values
##### strings.xml
All strings used throughout the application are defined here.
Having the definition of strings centralized helps to manage changes easily and in a single place.

```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    ...
    <string name="crosswalk">CROSSWALK</string>
    <string name="crosswalk_description">Crosswalk</string>
    <string name="error_found">Error found: </string>
    <string name="error_found_expression">Error found!</string>
    <string name="detections">DETECTIONS</string>
    <string name="device_not_registered">Device not registered</string>
    ...
</resources>
```

#### xml
##### automotive_app_desc
File where the template capability is declared as required for the apps using Android for Cars App Library
```xml
<?xml version="1.0" encoding="utf-8"?>
<automotiveApp>
    <uses name="template" />
</automotiveApp>
```

# Class Diagram
```mermaid
---
title: TSR_app
---
classDiagram
    class HistoryData{
        +historySigns: MutableListOf~Sign~
    }
    class Sign{
        +nameRes: Int
        +descriptionRes: Int
        +imageRes: Int
    }
    class SignsCatalog{
        +signs: ListOf~Sign~ 
    }
    class FcmManagement{
        - firebaseMessaging: FirebaseMessaging
        - carContext: CarContext
        - appScreen: TsrAppScreen
        - history: History
        -Instance: FcmManagement 
        -TAG: String 
        +Initialize() Boolean
        +getToken() String
        +manageNotification(context: Context, notification: RemoteMessage.Notification?)
        +createSignList(message: String) MutableList~String~
        +initialize(carContext: CarContext,appScreen: TsrAppScreen)
        +getInstance() FcmManagement
    }
    class FcmService{
        -fcmManagement: FcmManagement
        -TAG: String 
        +onCreate()
        +onMessageReceived(remoteMessage: RemoteMessage)
        +onNewToken(token: String) 
        +onDeletedMessages()
        +onSendError(messageId: String, exception: Exception)
    }
    class CurrentSign{
        - currentSignCarIcon: CarIcon
        - TAG: String
        - Instance: CurrentSign
        +getData(carContext: CarContext, signName: String)Sign
        +createImage(carContext: CarContext, currentSign: Sign)
        +addImageToPane(paneBuilder: Pane.Builder, carContext: CarContext)  
    }
    class History{
        -rows: List~Row~
        -receivedSignsList: MutableList~Sign~
        -TAG: String
        -Instance: History 
        +restructureContent(context: Context, currentSign: Sign, receivedSignsNameList: MutableList~String~)
        +createRows(carContext: CarContext, signList: List~Sign~ = historySigns)
        + addRowsToPaneBuilder(paneBuilder: Pane.Builder, carContext: CarContext) 
    }
    class TsrAppScreen{
        +currentSignName: String
        -history: History
        -mainSign: CurrentSign
        -pane: Pane
        -TAG: String
        +onGetTemplate() Template
    }
    class TsrAppSession {
        -tsrAppScreen: TsrAppScreen
        -fcmManagement: FcmManagement
        -TAG: String
        -instance: TsrAppSession
        +onCreateScreen(intent: Intent) Screen
    }
    class Utils {
        +sourceToCarIcon(context: CarContext, @DrawableRes resId: Int) CarIcon
        +getSignByName(context: CarContext, name: String) Sign
        +getSignByName(context: Context, name: String) Sign
    }
    class TsrAppService {
        + createHostValidator():HostValidator
        + onCreateSession():Session
    }
    TsrAppService --> TsrAppSession : Creates
    TsrAppSession --> FcmManagement : Initializes
    FcmService --> FcmManagement
    TsrAppSession --> TsrAppScreen : Creates
    FcmManagement --> TsrAppScreen
    TsrAppScreen --> CurrentSign
    TsrAppScreen --> History
    FcmManagement --> History
    CurrentSign --> Utils
    Utils --> SignsCatalog
    Sign --o SignsCatalog
    Sign --o HistoryData
    History --> HistoryData
    History --> Utils

```
# How to test communication with Firebase
<!-- TO DO: add details later -->
