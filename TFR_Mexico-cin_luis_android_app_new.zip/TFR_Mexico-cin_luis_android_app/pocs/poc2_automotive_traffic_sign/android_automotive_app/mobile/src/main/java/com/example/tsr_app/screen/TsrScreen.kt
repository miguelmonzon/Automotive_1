package com.example.tsr_app.screen

import android.annotation.SuppressLint
import androidx.activity.ComponentActivity
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.tsr_app.shared.data.HistoryData.historySigns
import com.example.tsr_app.shared.data.Sign
import com.example.tsr_app.shared.R as sharedR

class TsrScreen : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @Composable
    fun TSRApp() {
        Scaffold(
            topBar = {
                TsrAppBar(modifier = Modifier.padding(top = 15.dp))
            }
        ) {
            Column {
                CurrentStatusDisplay()
                HistoryLine()
            }
        }
    }
}

@Composable
fun TsrAppBar(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Transparent),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(id = sharedR.string.tsr),
            style = MaterialTheme.typography.displayLarge,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun CurrentStatusDisplay(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color.Transparent)
            .fillMaxWidth()
            .fillMaxHeight(0.85f)
            .padding(top = 75.dp, bottom = 5.dp, start = 7.dp, end = 7.dp),
    ) {
        // The base image is expected to be static.
        val baseImage = sharedR.drawable.car_front_min
        //This image shall vary along the detection process.
        val currentSign = sharedR.drawable.sign_empty

        BaseImage(baseImage = baseImage, modifier = Modifier.align(Alignment.Center))
        CurrentSignItem(currentSign = currentSign, modifier = Modifier.align(Alignment.TopEnd))
    }
}

@Composable
fun CurrentSignItem(@DrawableRes currentSign: Int, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .padding(top = 75.dp, end = 25.dp)
            .size(130.dp),
        backgroundColor = Color.Transparent,
        elevation = 8.dp
    ) {
        Row(
            Modifier
                .padding(16.dp)
                .sizeIn(minHeight = 130.dp)
                .fillMaxWidth()
                .background(Color.Transparent),
        ) {
            CurrentSignIcon(currentSign = currentSign)
        }
    }
}

@Composable
fun CurrentSignIcon(@DrawableRes currentSign: Int, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(currentSign),
        contentDescription = "Main signal",
        modifier = modifier
            .size(130.dp)
            .clip(RoundedCornerShape(8.dp)),
        contentScale = ContentScale.FillBounds,
        alignment = Alignment.TopCenter,
    )
}

@Composable
fun BaseImage(@DrawableRes baseImage: Int, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(baseImage),
        contentDescription = "Background",
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent),
        contentScale = ContentScale.FillBounds,
    )
}

@Composable
fun HistoryLine(modifier: Modifier = Modifier) {
    LazyRow(
        modifier = modifier.background(MaterialTheme.colorScheme.background),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(historySigns) {
            HistoryItem(
                historySign = it,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .padding(8.dp)
            )
        }
    }
}

@Composable
fun HistoryItem(historySign: Sign, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.size(width = 120.dp, height = 250.dp),
        backgroundColor = MaterialTheme.colorScheme.primaryContainer,
        elevation = 3.dp
    ) {
        Column(
            modifier = Modifier
                .padding(4.dp)
                .sizeIn(minHeight = 100.dp)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.primaryContainer),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            HistoryIcon(signalIcon = historySign.imageRes)
        }
    }
}

@Composable
fun HistoryIcon(@DrawableRes signalIcon: Int, modifier: Modifier = Modifier) {
    Image(
        modifier = modifier
            .size(100.dp)
            .clip(RoundedCornerShape(8.dp)),
        painter = painterResource(id = signalIcon),
        contentScale = ContentScale.Fit,
        alignment = Alignment.Center,
        contentDescription = null,
    )
}